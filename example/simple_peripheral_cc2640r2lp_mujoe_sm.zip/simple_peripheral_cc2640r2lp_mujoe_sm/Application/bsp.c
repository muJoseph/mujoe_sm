/*
 * bsp.c
 *
 *  Created on: Dec 27, 2022
 *      Author: joe
 */

//////////////////////////////////////////////////////////////////////////////////////////////
//  INCLUDE
//////////////////////////////////////////////////////////////////////////////////////////////

#include "bsp.h"
#include <string.h>

/* Driver configuration */
#include <Board.h>

//////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
//////////////////////////////////////////////////////////////////////////////////////////////

typedef struct _bsp
{
    PIN_State           pinState;
    PIN_Handle          pinHdl;

}bsp_t;

//////////////////////////////////////////////////////////////////////////////////////////////
//  LOCAL VAR
//////////////////////////////////////////////////////////////////////////////////////////////

static const PIN_Config pinTbl[] = {

    CC2640R2_LAUNCHXL_PIN_RLED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,       /* LED initially off */
    CC2640R2_LAUNCHXL_PIN_GLED | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,       /* LED initially off */
    PIN_TERMINATE
};

static bsp_t bsp;
static bsp_t *ctx;

//////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
//////////////////////////////////////////////////////////////////////////////////////////////

bool bsp_initPins( void )
{
    bool retVal = false;

    ctx = &bsp;
    memset(ctx,0,sizeof(bsp_t));

    if( ( ctx->pinHdl = PIN_open( &ctx->pinState, pinTbl ) ) != NULL )
    {
        retVal = true;
    }

    return retVal;

}// bsp_initPins

bool bsp_control_GLED( bool on )
{
    return PIN_setOutputValue( &ctx->pinState,
                               CC2640R2_LAUNCHXL_PIN_GLED,
                               on ) == PIN_SUCCESS;
} // bsp_control_GLED

bool bsp_control_RLED( bool on )
{
    return PIN_setOutputValue( &ctx->pinState,
                               CC2640R2_LAUNCHXL_PIN_RLED,
                               on ) == PIN_SUCCESS;
} // bsp_control_GLED

bool bsp_toggle_RLED( void )
{
    return bsp_control_RLED( !PIN_getOutputValue(CC2640R2_LAUNCHXL_PIN_RLED) );
} // bsp_toggle_RLED

bool bsp_toggle_GLED( void )
{
    return bsp_control_GLED( !PIN_getOutputValue(CC2640R2_LAUNCHXL_PIN_GLED) );
} // bsp_toggle_GLED


