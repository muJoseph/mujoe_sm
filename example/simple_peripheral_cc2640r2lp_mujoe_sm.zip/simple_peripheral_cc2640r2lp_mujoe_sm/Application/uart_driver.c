/*
 * uart_driver.c
 *
 *  Created on: Dec 21, 2022
 *      Author: joe
 */

//////////////////////////////////////////////////////////////////////////////////////////////
//  INCLUDE
/////////////////////////////////////////////////////////////////////////////////////////////


#include "uart_driver.h"


//////////////////////////////////////////////////////////////////////////////////////////////
//  LOCAL VAR
/////////////////////////////////////////////////////////////////////////////////////////////

static uart_driver_cfg_t cfg = {0};
static UART_Handle uart;
static UART_Params uartParams;


#define UART_DRIVER_RX_BUFF_LEN                 1
static uint8 rxBuffer[UART_DRIVER_RX_BUFF_LEN] = {0};

//////////////////////////////////////////////////////////////////////////////////////////////
//  API
/////////////////////////////////////////////////////////////////////////////////////////////

uint8 uart_driver_init( uart_driver_cfg_t *pCfg )
{
    cfg = *pCfg;

    UART_init();

    /* Create a UART with data processing off. */
    UART_Params_init(&uartParams);

    uartParams.writeMode = UART_MODE_BLOCKING;
    uartParams.readMode = UART_MODE_CALLBACK;


    if( cfg.pCbs->writeCallback && uartParams.writeMode == UART_MODE_CALLBACK )
        uartParams.writeCallback = cfg.pCbs->writeCallback;

    if( cfg.pCbs->readCallback && uartParams.readMode == UART_MODE_CALLBACK )
        uartParams.readCallback = cfg.pCbs->readCallback;

    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.readEcho = UART_ECHO_OFF;
    uartParams.baudRate = 115200;

    uart = UART_open(Board_UART0, &uartParams);

    return ( uart != NULL ) ? 1 : 0;

} // uart_driver_init


uint8 uart_driver_write( uint8 *pTxBuf, int len )
{
    return (UART_write(uart, pTxBuf, len) == UART_STATUS_SUCCESS) ? 1 : 0;
} // uart_driver_write


uint8* uart_driver_getRxBufferHandle( int *pBuffLen )
{
    *pBuffLen = UART_DRIVER_RX_BUFF_LEN;
    return rxBuffer;
}// uart_driver_getRxBufferHandle


uint8 uart_driver_listen( int numBytes )
{
    if( numBytes > UART_DRIVER_RX_BUFF_LEN )
        return 0;

    return (UART_read(uart, rxBuffer, numBytes) == UART_STATUS_SUCCESS) ? 1 : 0;

} // uart_driver_listen



