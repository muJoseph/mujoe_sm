/*
 * uart_driver.h
 *
 *  Created on: Dec 21, 2022
 *      Author: joe
 */

#ifndef UART_DRIVER_H_
#define UART_DRIVER_H_

//////////////////////////////////////////////////////////////////////////////////////////////
//  INCLUDE
/////////////////////////////////////////////////////////////////////////////////////////////

#include <hal_types.h>
#include <ti/drivers/UART.h>

/* Example/Board Header files */
#include "Board.h"

//////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
/////////////////////////////////////////////////////////////////////////////////////////////

typedef struct _uart_driver_Cb
{
    UART_Callback   readCallback;    /*!< Pointer to read callback function for callback mode. */
    UART_Callback   writeCallback;   /*!< Pointer to write callback function for callback mode. */

}uart_driver_Cb_t;

typedef struct _uart_driver_cfg
{
    uart_driver_Cb_t *pCbs;

}uart_driver_cfg_t;

//////////////////////////////////////////////////////////////////////////////////////////////
//  INCLUDE
/////////////////////////////////////////////////////////////////////////////////////////////

extern uint8 uart_driver_init( uart_driver_cfg_t *pCfg );
extern uint8* uart_driver_getRxBufferHandle( int *pBuffLen );
extern uint8 uart_driver_write( uint8 *pTxBuf, int len );
extern uint8 uart_driver_listen( int numBytes );


#endif /* UART_DRIVER_H_ */
