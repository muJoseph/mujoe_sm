/*
 * uart_sm.h
 *
 *  Created on: Dec 15, 2022
 *      Author: joe
 */

#ifndef UART_SM_H_
#define UART_SM_H_


//////////////////////////////////////////////////////////////////////////////////////////////
//  INCLUDE
/////////////////////////////////////////////////////////////////////////////////////////////

#include "mujoe_sm.h"
#include "uart_driver.h"

//////////////////////////////////////////////////////////////////////////////////////////////
//  TYPES
/////////////////////////////////////////////////////////////////////////////////////////////

// UART State machine states
typedef enum
{
    UART_SM_STATE_IDLE = (mujoe_sm_s_index_t)0,
    UART_SM_STATE_AWT_CMD,
    UART_SM_STATE_CMD_RXD,
    UART_SM_STATE_CMD_TIMEOUT,
    UART_SM_NUM_STATES,

}uart_sm_states_t;

typedef struct _uart_sm_host_arg
{
    uint8       *pRxBuffer;
    int         rxBufferLen;

}uart_sm_host_arg_t;

//////////////////////////////////////////////////////////////////////////////////////////////
//  CONSTANTS
/////////////////////////////////////////////////////////////////////////////////////////////

// UART state machine states return codes
#define UART_SM_RET_CODE_SUCCESS                 (mujoe_sm_s_code_t)1
#define UART_SM_RET_CODE_LISTEN_FOR_CMD          (mujoe_sm_s_code_t)2
#define UART_SM_RET_CODE_CMD_RXD                 (mujoe_sm_s_code_t)3

//////////////////////////////////////////////////////////////////////////////////////////////
//  API
/////////////////////////////////////////////////////////////////////////////////////////////

extern void uart_sm_init( void );
extern mujoe_sm_err_t uart_sm_registerCallbacks( mujoe_sm_Cbs_t *pCBs );
extern mujoe_sm_err_t uart_sm_data_rxd( void );
extern mujoe_sm_err_t uart_sm_start( mujoe_sm_s_time_ms_t delay_ms );
extern mujoe_sm_err_t uart_sm_run( void );

#endif /* UART_SM_H_ */
