/*
 * uart_sm.c
 *
 *  Created on: Dec 15, 2022
 *      Author: joe
 */



//////////////////////////////////////////////////////////////////////////////////////////////
//  INCLUDE
/////////////////////////////////////////////////////////////////////////////////////////////

#include "uart_sm.h"

//////////////////////////////////////////////////////////////////////////////////////////////
//  EXTERN VAR
/////////////////////////////////////////////////////////////////////////////////////////////

extern const mujoe_sm_state_Fp_t uart_sm_state_tbl[UART_SM_NUM_STATES];

//////////////////////////////////////////////////////////////////////////////////////////////
//  LOCAL VAR
/////////////////////////////////////////////////////////////////////////////////////////////

static uart_sm_host_arg_t hostArg = {0};

// State machine context
static mujoe_sm_t uart_sm;

// State machine transition table
static const mujoe_sm_trans_t uart_sm_trans_tbl[] =
{
   // Current State ------------------------------ Return Code -------------------------------------------------- Next State

   // UART_SM_STATE_IDLE rules
   {  .curr = UART_SM_STATE_IDLE,          .code = UART_SM_RET_CODE_LISTEN_FOR_CMD,                              .next = UART_SM_STATE_AWT_CMD },

   // UART_SM_STATE_AWT_CMD rules
   {  .curr = UART_SM_STATE_AWT_CMD,       .code = MUJOE_SM_RET_CODE_EXT_TRIG_RXD | UART_SM_RET_CODE_CMD_RXD,    .next = UART_SM_STATE_CMD_RXD },
   {  .curr = UART_SM_STATE_AWT_CMD,       .code = MUJOE_SM_RET_CODE_TIMEOUT | UART_SM_RET_CODE_CMD_RXD,         .next = UART_SM_STATE_CMD_TIMEOUT },

   // UART_SM_STATE_CMD_RXD rules
   {  .curr = UART_SM_STATE_CMD_RXD,       .code = UART_SM_RET_CODE_SUCCESS,                                     .next = UART_SM_STATE_AWT_CMD },

   // UART_SM_STATE_CMD_TIMEOUT rules
   {  .curr = UART_SM_STATE_CMD_TIMEOUT,   .code = UART_SM_RET_CODE_SUCCESS,                                     .next = UART_SM_STATE_AWT_CMD },

};

//////////////////////////////////////////////////////////////////////////////////////////////
//  FUNCTIONS
/////////////////////////////////////////////////////////////////////////////////////////////

void uart_sm_init( void )
{
    // Initialize local host arg structure, pass to state machine context via mujoe_sm_cfg_t.pHostVar
    hostArg.pRxBuffer = uart_driver_getRxBufferHandle( &hostArg.rxBufferLen );

    mujoe_sm_cfg_t cfg =
    {
         .pStateTbl     = (mujoe_sm_state_Fp_t *)uart_sm_state_tbl,
         .numStates     = UART_SM_NUM_STATES,
         .pTransTbl     = (mujoe_sm_trans_t *)uart_sm_trans_tbl,
         .numTrans      = sizeof(uart_sm_trans_tbl)/sizeof(mujoe_sm_trans_t),
         .pHostVar      = &hostArg,
    };

    mujoe_sm_initCtx( &uart_sm, &cfg );

}// uart_sm_init

mujoe_sm_err_t uart_sm_registerCallbacks( mujoe_sm_Cbs_t *pCBs )
{
    return mujoe_sm_registerCallbacks( &uart_sm, pCBs );

} // uart_sm_registerCallbacks


mujoe_sm_err_t uart_sm_start( mujoe_sm_s_time_ms_t delay_ms )
{
    return mujoe_sm_start( &uart_sm, delay_ms );
} // uart_sm_start

mujoe_sm_err_t uart_sm_data_rxd( void )
{
    return mujoe_sm_trigger( &uart_sm, UART_SM_RET_CODE_CMD_RXD );

}// uart_sm_data_rxd

mujoe_sm_err_t uart_sm_run( void )
{
    return mujoe_sm_run( &uart_sm );

} // uart_sm_run


