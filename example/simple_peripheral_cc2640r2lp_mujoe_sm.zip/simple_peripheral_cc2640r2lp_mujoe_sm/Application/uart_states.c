/*
 * uart_states.c
 *
 *  Created on: Dec 15, 2022
 *      Author: joe
 */


//////////////////////////////////////////////////////////////////////////////////////////////
//  INCLUDE
/////////////////////////////////////////////////////////////////////////////////////////////

#include "uart_sm.h"
#include "uart_driver.h"
#include <stdio.h>

//////////////////////////////////////////////////////////////////////////////////////////////
//  LOCAL VAR
/////////////////////////////////////////////////////////////////////////////////////////////

// Buffer for creating output messages
#define MSG_BUFFER_LEN          100
static uint8 msgBuffer[MSG_BUFFER_LEN] = {0};

//////////////////////////////////////////////////////////////////////////////////////////////
//  STATES
/////////////////////////////////////////////////////////////////////////////////////////////

static mujoe_sm_s_ret uart_idle( void* pHostVar )
{
    mujoe_sm_s_ret ret = { .code = UART_SM_RET_CODE_LISTEN_FOR_CMD, .time_ms = 100 };
    return ret;
} // uart_idle

static mujoe_sm_s_ret uart_awaitCmd( void* pHostVar )
{
    // Set trigger code and state machine driver await trigger flag within return code structure
    mujoe_sm_s_ret ret = { .code = MUJOE_SM_RET_CODE_AWAIT_EXT_TRIG | UART_SM_RET_CODE_CMD_RXD, .time_ms = 5000 };

    uart_driver_listen( 1 );

    uint8 msg[] = "awaiting command...\r\n";
    uart_driver_write( (uint8 *)msg, strlen((const char *)msg) );
    return ret;

} // uart_awaitCmd

static mujoe_sm_s_ret uart_cmdReceived( void* pHostVar )
{

    uart_sm_host_arg_t *pHostArg = (uart_sm_host_arg_t *)pHostVar;

    if( pHostArg )
    {
        // Null terminate character
        const char cmdStr[2] = {pHostArg->pRxBuffer[0],'\0'};
        int len = snprintf ( (char *)msgBuffer, MSG_BUFFER_LEN, "command received: %s \r\n", cmdStr );
        uart_driver_write( (uint8 *)msgBuffer, len );
        //uart_driver_write( (uint8 *)pHostArg->pRxBuffer, 1);
    }

    mujoe_sm_s_ret ret = { .code = UART_SM_RET_CODE_SUCCESS, .time_ms = 0 };
    uint8 msg[] = "command received...\r\n";
    uart_driver_write( (uint8 *)msg, strlen((const char *)msg) );
    return ret;
} // uart_cmdReceived

static mujoe_sm_s_ret uart_cmdTimeout( void* pHostVar )
{
    mujoe_sm_s_ret ret = { .code = UART_SM_RET_CODE_SUCCESS, .time_ms = 0 };
    uint8 msg[] = "timed out...\r\n";
    uart_driver_write( (uint8 *)msg, strlen((const char *)msg) );
    return ret;

} // uart_cmdTimeout

const mujoe_sm_state_Fp_t uart_sm_state_tbl[UART_SM_NUM_STATES] =
{
     uart_idle,
     uart_awaitCmd,
     uart_cmdReceived,
     uart_cmdTimeout,
};


